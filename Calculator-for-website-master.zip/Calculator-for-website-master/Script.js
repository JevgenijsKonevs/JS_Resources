// Calculator

    let persons = document.querySelectorAll ('.counter-block-input')[0],
        restDays = document.querySelectorAll('.counter-block-input')[1],
        place = document.getElementById('select'),
        totalValue = document.getElementById('total'),
        personsSum = 0,
        daysSum = 0,
        total = 0;

        totalValue.innerText = 0; // обнулить сумму в счетчике на сайте
        
        persons.addEventListener('change', function(){
            personsSum = +this.value; // получить значение на переменной persons
            total = (daysSum + personsSum) * 4000; // формулу предоставляет заказчик

            if (restDays.value == "" || persons.value == '') {
                totalValue.innerHTML = 0;  // если не заполнено одно из полей, то сумма равна 0
            } else {
                totalValue.innerHTML = total; // передать значение переменной total 
            }

            
        });
        restDays.addEventListener('change', function(){
            daysSum = +this.value; // получить значение на переменной persons
            total = (daysSum + personsSum) * 4000; // формулу предоставляет заказчик

            if (persons.value == "") {
                totalValue.innerHTML = 0;  // если не заполнено одно из полей, то сумма равна 0
            } else {
                totalValue.innerHTML = total; // передать значение переменной total 
            }
        });

        place.addEventListener ('change', function(){
            if (restDays.value =='' || persons.value == ''){
                totalValue.innerHTML = 0;
            } else {
                let a = total;
                totalValue.innerHTML = a *this.options[this.selectedIndex].value; // получаем определенное значение "value" в определенном "options" из HTML кода
            }
        });
